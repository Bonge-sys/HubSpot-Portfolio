import axios from "axios";
import dotenv from "dotenv";
import fs from "fs";

dotenv.config();

const HUBSPOT_TOKEN = process.env.HUBSPOT_TOKEN;
const CRM_API_URL = process.env.CRM_API_URL;

// Fetch updated records from external CRM (mocked)
async function fetchCRMContacts() {
    const res = await axios.get(CRM_API_URL);
    return res.data.contacts || [];
}

// Transform CRM data to HubSpot format
function transformForHubSpot(contact) {
    return {
        properties: {
            firstname: contact.first_name,
            lastname: contact.last_name,
            email: contact.email,
            phone: contact.phone,
            external_crm_id: contact.id
        }
    };
}

// Upsert (create or update) record in HubSpot
async function upsertToHubSpot(contact) {
    try {
        const search = await axios.post(
        "https://api.hubapi.com/crm/v3/objects/contacts/search",
        {
            filterGroups: [
            {
                filters: [
                { propertyName: "external_crm_id", operator: "EQ", value: contact.id }
                ]
            }
            ]
        },
        {
            headers: {
            Authorization: `Bearer ${HUBSPOT_TOKEN}`,
            "Content-Type": "application/json"
            }
        }
        );

        const existing = search.data.results[0];

        if (existing) {
            await axios.patch(
                `https://api.hubapi.com/crm/v3/objects/contacts/${existing.id}`,
                transformForHubSpot(contact),
                { headers: { Authorization: `Bearer ${HUBSPOT_TOKEN}` } }
            );
            console.log(`Updated contact: ${contact.email}`);
        } else {
            await axios.post(
                "https://api.hubapi.com/crm/v3/objects/contacts",
                transformForHubSpot(contact),
                { headers: { Authorization: `Bearer ${HUBSPOT_TOKEN}` } }
            );
            console.log(`Created contact: ${contact.email}`);
        }
    } catch (err) {
        console.error(`Error syncing ${contact.email}:`, err.response?.data || err.message);
    }
}

// Main sync function
async function runSync() {
    console.log("Starting CRM → HubSpot sync...");
    const contacts = await fetchCRMContacts();

    for (const contact of contacts) {
        await upsertToHubSpot(contact);
    }

    console.log("Sync complete.");
}

runSync();
