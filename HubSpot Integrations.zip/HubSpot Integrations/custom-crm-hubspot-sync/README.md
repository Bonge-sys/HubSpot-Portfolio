# Custom CRM → HubSpot Integration Example

This project demonstrates how our team builds reliable integrations between external CRMs and HubSpot using API automation.

## Features
- Fetches data from an external CRM (mocked with JSON)
- Transforms data into HubSpot-compatible payloads
- Creates or updates records via HubSpot API
- Error handling and console logs for validation

## Stack
- Node.js
- HubSpot CRM v3 API
- Axios
- dotenv

## Setup
1. Clone this project and navigate into the directory.
2. Install dependencies:
   ```bash
   npm install
