import axios from "axios";
import dotenv from "dotenv";
import { google } from "googleapis";
import fs from "fs";

dotenv.config();

const HUBSPOT_TOKEN = process.env.HUBSPOT_TOKEN;
const SHEET_ID = process.env.GOOGLE_SHEET_ID;
const SERVICE_KEY_PATH = process.env.GOOGLE_SERVICE_ACCOUNT_KEY;

// Authenticate with Google Sheets API
async function authorizeGoogle() {
    const credentials = JSON.parse(fs.readFileSync(SERVICE_KEY_PATH, "utf8"));
    const auth = new google.auth.GoogleAuth({
        credentials,
        scopes: ["https://www.googleapis.com/auth/spreadsheets"]
    });
    return auth;
}

// Fetch contacts from HubSpot
async function fetchHubSpotContacts() {
    const res = await axios.get("https://api.hubapi.com/crm/v3/objects/contacts", {
        headers: { Authorization: `Bearer ${HUBSPOT_TOKEN}` },
        params: { limit: 10, properties: "firstname,lastname,email,phone" }
    });

    return res.data.results.map(c => ({
        firstname: c.properties.firstname || "",
        lastname: c.properties.lastname || "",
        email: c.properties.email || "",
        phone: c.properties.phone || ""
    }));
}

// Write contacts to Google Sheet
async function writeToSheet(auth, contacts) {
    const sheets = google.sheets({ version: "v4", auth });
    const rows = [["First Name", "Last Name", "Email", "Phone"]];

    contacts.forEach(c => {
        rows.push([c.firstname, c.lastname, c.email, c.phone]);
    });

    await sheets.spreadsheets.values.update({
        spreadsheetId: SHEET_ID,
        range: "Sheet1!A1",
        valueInputOption: "RAW",
        requestBody: { values: rows }
    });

    console.log("Contacts written to Google Sheet successfully.");
}

// Main function
async function runIntegration() {
    console.log("Starting HubSpot → Google Sheets sync...");

    const contacts = await fetchHubSpotContacts();
    const auth = await authorizeGoogle();
    await writeToSheet(auth, contacts);

    console.log("Sync complete.");
}

runIntegration().catch(err => {
    console.error("Error running sync:", err.response?.data || err.message);
});
