# HubSpot ↔ Google Sheets Integration

This example demonstrates how to sync HubSpot contact data into a Google Sheet using the HubSpot and Google APIs.

## Features
- Fetches contact data from HubSpot (CRM v3 API)
- Writes contact details to a Google Sheet
- Uses service account authentication for secure access

## Tech Stack
- Node.js
- HubSpot CRM API
- Google Sheets API
- Axios, dotenv, googleapis

## Setup
1. Create a service account in Google Cloud and download the JSON credentials.
2. Share your target Google Sheet with the service account email.
3. Copy `.env.example` → `.env` and fill in your details.
4. Run the sync:
   ```bash
   node index.js
