# HubSpot ↔ Xero Integration Example

This project demonstrates how to automate invoice creation in Xero when a HubSpot deal closes.

## Features
- Maps HubSpot deal data into Xero invoice format
- Creates an invoice in Xero through the API
- Updates the corresponding HubSpot deal with invoice info
- Mock event data for local testing

## Stack
- Node.js
- HubSpot CRM API
- Xero Accounting API
- Axios, dotenv

## Setup
1. Create a `.env` file with your HubSpot and Xero tokens.
2. Run the script:
   ```bash
   node index.js
