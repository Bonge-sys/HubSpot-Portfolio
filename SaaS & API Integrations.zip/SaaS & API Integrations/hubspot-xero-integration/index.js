import axios from "axios";
import dotenv from "dotenv";
import fs from "fs";

dotenv.config();

const HUBSPOT_TOKEN = process.env.HUBSPOT_TOKEN;
const XERO_API_URL = process.env.XERO_API_URL;
const XERO_TOKEN = process.env.XERO_TOKEN;

// Simulate deal event (in real integration this would be a webhook)
function getDealEvent() {
    const data = fs.readFileSync("./mock/deal-event.json", "utf8");
    return JSON.parse(data);
}

// Create invoice payload for Xero
function mapToXeroInvoice(deal) {
    return {
        Type: "ACCREC",
        Contact: { Name: deal.company.name, EmailAddress: deal.company.email },
        LineItems: [
        {
            Description: deal.dealName,
            Quantity: 1,
            UnitAmount: deal.amount,
            AccountCode: "200"
        }
        ],
        Date: new Date().toISOString(),
        DueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
        Reference: `HubSpot Deal #${deal.dealId}`,
        Status: "AUTHORISED"
    };
}

// Send invoice to Xero
async function sendInvoiceToXero(invoice) {
    const response = await axios.post(XERO_API_URL, { Invoices: [invoice] }, {
        headers: {
        Authorization: `Bearer ${XERO_TOKEN}`,
        "Content-Type": "application/json"
        }
    });

    console.log("Invoice created in Xero:", response.data);
}

// Optionally update HubSpot deal with invoice link
async function updateHubSpotDeal(dealId, invoiceNumber) {
    const url = `https://api.hubapi.com/crm/v3/objects/deals/${dealId}`;
    const payload = { properties: { xero_invoice_number: invoiceNumber } };

    await axios.patch(url, payload, {
        headers: {
        Authorization: `Bearer ${HUBSPOT_TOKEN}`,
        "Content-Type": "application/json"
        }
    });

    console.log(`HubSpot deal ${dealId} updated with invoice ${invoiceNumber}`);
}

// Main function
async function runIntegration() {
    console.log("Starting HubSpot → Xero sync...");
    const deal = getDealEvent();
    const invoice = mapToXeroInvoice(deal);

    try {
        await sendInvoiceToXero(invoice);
        await updateHubSpotDeal(deal.dealId, "INV-0001");
        console.log("Integration complete.");
    } catch (err) {
        console.error("Integration failed:", err.response?.data || err.message);
    }
}

runIntegration();
